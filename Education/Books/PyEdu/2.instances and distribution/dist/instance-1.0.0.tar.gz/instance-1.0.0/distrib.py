from distutils.core import setup

setup(
    name = 'instance',
    version = '1.0.0',
    py_modules = ['instances2'],
    author = 'DWle',
)